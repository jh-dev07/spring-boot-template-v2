# Read Me First
The following was discovered as part of building this project:

* The JVM level was changed to '21' as Vaadin requires Java 21 or later.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/4.1.2/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.1.2/maven-plugin/build-image.html)
* [GraalVM Native Image Support](https://docs.spring.io/spring-boot/4.1.2/reference/packaging/native-image/introducing-graalvm-native-images.html)
* [Spring Integration JMS Module Reference Guide](https://docs.spring.io/spring-integration/reference/jms.html)
* [Spring Integration AMQP Module Reference Guide](https://docs.spring.io/spring-integration/reference/amqp.html)
* [Spring Integration JDBC Module Reference Guide](https://docs.spring.io/spring-integration/reference/jdbc.html)
* [Spring Integration JPA Module Reference Guide](https://docs.spring.io/spring-integration/reference/jpa.html)
* [Spring Integration MongoDB Module Reference Guide](https://docs.spring.io/spring-integration/reference/mongodb.html)
* [Spring Integration R2DBC Module Reference Guide](https://docs.spring.io/spring-integration/reference/r2dbc.html)
* [Spring Integration Redis Module Reference Guide](https://docs.spring.io/spring-integration/reference/redis.html)
* [Spring Integration Test Module Reference Guide](https://docs.spring.io/spring-integration/reference/testing.html)
* [Spring Integration Apache Kafka Module Reference Guide](https://docs.spring.io/spring-integration/reference/kafka.html)
* [Spring Integration Mail Module Reference Guide](https://docs.spring.io/spring-integration/reference/mail.html)
* [Spring Integration RSocket Module Reference Guide](https://docs.spring.io/spring-integration/reference/rsocket.html)
* [Spring Integration Security Module Reference Guide](https://docs.spring.io/spring-integration/reference/security.html)
* [Spring Integration HTTP Module Reference Guide](https://docs.spring.io/spring-integration/reference/http.html)
* [Spring Integration WebFlux Module Reference Guide](https://docs.spring.io/spring-integration/reference/webflux.html)
* [Spring Integration STOMP Module Reference Guide](https://docs.spring.io/spring-integration/reference/stomp.html)
* [Spring Integration WebSocket Module Reference Guide](https://docs.spring.io/spring-integration/reference/web-sockets.html)
* [Spring Integration Web Services Module Reference Guide](https://docs.spring.io/spring-integration/reference/ws.html)
* [Spring Integration gRPC Module Reference Guide](https://docs.spring.io/spring-integration/reference/grpc.html)
* [Spring Boot Testcontainers support](https://docs.spring.io/spring-boot/4.1.2/reference/testing/testcontainers.html#testing.testcontainers)
* [Testcontainers ActiveMQ Module Reference Guide](https://java.testcontainers.org/modules/activemq/)
* [Testcontainers ActiveMQ Module Reference Guide](https://java.testcontainers.org/modules/activemq/)
* [Testcontainers RabbitMQ Module Reference Guide](https://java.testcontainers.org/modules/rabbitmq/)
* [Testcontainers Cassandra Module Reference Guide](https://java.testcontainers.org/modules/databases/cassandra/)
* [Testcontainers Couchbase Module Reference Guide](https://java.testcontainers.org/modules/databases/couchbase/)
* [Testcontainers Elasticsearch Container Reference Guide](https://java.testcontainers.org/modules/elasticsearch/)
* [Testcontainers MongoDB Module Reference Guide](https://java.testcontainers.org/modules/databases/mongodb/)
* [Testcontainers Neo4j Module Reference Guide](https://java.testcontainers.org/modules/databases/neo4j/)
* [Testcontainers R2DBC support Reference Guide](https://java.testcontainers.org/modules/databases/r2dbc/)
* [Testcontainers DB2 Module Reference Guide](https://java.testcontainers.org/modules/databases/db2/)
* [Testcontainers Kafka Modules Reference Guide](https://java.testcontainers.org/modules/kafka/)
* [Testcontainers MariaDB Module Reference Guide](https://java.testcontainers.org/modules/databases/mariadb/)
* [Testcontainers MySQL Module Reference Guide](https://java.testcontainers.org/modules/databases/mysql/)
* [Testcontainers Oracle-Free Module Reference Guide](https://java.testcontainers.org/modules/databases/oraclefree/)
* [Testcontainers Postgres Module Reference Guide](https://java.testcontainers.org/modules/databases/postgres/)
* [Testcontainers Pulsar Module Reference Guide](https://java.testcontainers.org/modules/pulsar/)
* [Testcontainers MS SQL Server Module Reference Guide](https://java.testcontainers.org/modules/databases/mssqlserver/)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/4.1.2/reference/using/devtools.html)
* [Spring Configuration Processor](https://docs.spring.io/spring-boot/4.1.2/specification/configuration-metadata/annotation-processor.html)
* [Docker Compose Support](https://docs.spring.io/spring-boot/4.1.2/reference/features/dev-services.html#features.dev-services.docker-compose)
* [Spring Modulith](https://docs.spring.io/spring-modulith/reference/)
* [Spring Web](https://docs.spring.io/spring-boot/4.1.2/reference/web/servlet.html)
* [Spring Reactive Web](https://docs.spring.io/spring-boot/4.1.2/reference/web/reactive.html)
* [HTTP Client](https://docs.spring.io/spring-boot/4.1.2/reference/io/rest-client.html#io.rest-client.restclient)
* [Reactive HTTP Client](https://docs.spring.io/spring-boot/4.1.2/reference/io/rest-client.html#io.rest-client.webclient)
* [Spring for GraphQL](https://docs.spring.io/spring-boot/4.1.2/reference/web/spring-graphql.html)
* [Rest Repositories](https://docs.spring.io/spring-boot/4.1.2/how-to/data-access.html#howto.data-access.exposing-spring-data-repositories-as-rest)
* [Spring Session for Spring Data Redis](https://docs.spring.io/spring-session/reference/)
* [Spring Session for JDBC](https://docs.spring.io/spring-session/reference/)
* [Spring HATEOAS](https://docs.spring.io/spring-boot/4.1.2/reference/web/spring-hateoas.html)
* [Spring Web Services](https://docs.spring.io/spring-boot/4.1.2/reference/io/webservices.html)
* [Jersey](https://docs.spring.io/spring-boot/4.1.2/reference/web/servlet.html#web.servlet.jersey)
* [Vaadin](https://vaadin.com/docs)
* [SpringDoc OpenAPI](https://springdoc.org/)
* [Thymeleaf](https://docs.spring.io/spring-boot/4.1.2/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Apache Freemarker](https://docs.spring.io/spring-boot/4.1.2/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Mustache](https://docs.spring.io/spring-boot/4.1.2/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Groovy Templates](https://docs.spring.io/spring-boot/4.1.2/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)
* [Spring Security](https://docs.spring.io/spring-boot/4.1.2/reference/web/spring-security.html)
* [OAuth2 Client](https://docs.spring.io/spring-boot/4.1.2/reference/web/spring-security.html#web.security.oauth2.client)
* [OAuth2 Authorization Server](https://docs.spring.io/spring-boot/4.1.2/reference/web/spring-security.html#web.security.oauth2.authorization-server)
* [SAML 2.0](https://docs.spring.io/spring-boot/4.1.2/reference/web/spring-security.html#web.security.saml2)
* [WebAuthn for Spring Security](https://docs.spring.io/spring-security/reference/servlet/authentication/passkeys.html)
* [OAuth2 Resource Server](https://docs.spring.io/spring-boot/4.1.2/reference/web/spring-security.html#web.security.oauth2.server)
* [LDAP](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.ldap)
* [Spring Data LDAP](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.ldap)
* [Okta Spring Boot documentation](https://github.com/okta/okta-spring-boot#readme)
* [JDBC API](https://docs.spring.io/spring-boot/4.1.2/reference/data/sql.html)
* [R2DBC API](https://docs.spring.io/spring-boot/4.1.2/reference/data/sql.html#data.sql.r2dbc)
* [Spring Data JDBC](https://docs.spring.io/spring-boot/4.1.2/reference/data/sql.html#data.sql.jdbc)
* [Spring Data JPA](https://docs.spring.io/spring-boot/4.1.2/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Spring Data R2DBC](https://docs.spring.io/spring-boot/4.1.2/reference/data/sql.html#data.sql.r2dbc)
* [Liquibase Migration](https://docs.spring.io/spring-boot/4.1.2/how-to/data-initialization.html#howto.data-initialization.migration-tool.liquibase)
* [Flyway Migration](https://docs.spring.io/spring-boot/4.1.2/how-to/data-initialization.html#howto.data-initialization.migration-tool.flyway)
* [JOOQ Access Layer](https://docs.spring.io/spring-boot/4.1.2/reference/data/sql.html#data.sql.jooq)
* [Spring Data Redis (Access+Driver)](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.redis)
* [Spring Data Reactive Redis](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.redis)
* [MongoDB](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.mongodb)
* [Spring Data MongoDB](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.mongodb)
* [Spring Data Reactive MongoDB](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.mongodb)
* [Elasticsearch](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.elasticsearch)
* [Spring Data Elasticsearch](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.elasticsearch)
* [Cassandra](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.cassandra)
* [Spring Data for Apache Cassandra](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.cassandra)
* [Spring Data Reactive for Apache Cassandra](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.cassandra)
* [Couchbase](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.couchbase)
* [Spring Data Couchbase](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.couchbase)
* [Spring Data Reactive Couchbase](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.couchbase)
* [Neo4j](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.neo4j)
* [Spring Data Neo4j](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.neo4j)
* [Spring Integration](https://docs.spring.io/spring-boot/4.1.2/reference/messaging/spring-integration.html)
* [Spring for RabbitMQ](https://docs.spring.io/spring-boot/4.1.2/reference/messaging/amqp.html)
* [Spring for RabbitMQ Streams](https://docs.spring.io/spring-amqp/reference/stream.html)
* [Spring for Apache Kafka](https://docs.spring.io/spring-boot/4.1.2/reference/messaging/kafka.html)
* [Apache Kafka Streams Support](https://docs.spring.io/spring-kafka/reference/streams.html)
* [Apache Kafka Streams Binding Capabilities of Spring Cloud Stream](https://docs.spring.io/spring-cloud-stream/reference/kafka/kafka-streams-binder/usage.html)
* [Spring for Apache ActiveMQ 5](https://docs.spring.io/spring-boot/4.1.2/reference/messaging/jms.html#messaging.jms.activemq)
* [Spring for Apache ActiveMQ Artemis](https://docs.spring.io/spring-boot/4.1.2/reference/messaging/jms.html#messaging.jms.artemis)
* [Spring for Apache Pulsar](https://docs.spring.io/spring-boot/4.1.2/reference/messaging/pulsar.html)
* [WebSocket](https://docs.spring.io/spring-boot/4.1.2/reference/messaging/websockets.html)
* [RSocket](https://rsocket.io/)
* [Spring Batch](https://docs.spring.io/spring-boot/4.1.2/how-to/batch.html)
* [Spring Batch JDBC](https://docs.spring.io/spring-boot/4.1.2/how-to/batch.html)
* [Spring Batch MongoDB](https://docs.spring.io/spring-boot/4.1.2/how-to/batch.html)
* [Hazelcast](https://docs.spring.io/spring-boot/4.1.2/reference/io/hazelcast.html)
* [Validation](https://docs.spring.io/spring-boot/4.1.2/reference/io/validation.html)
* [Java Mail Sender](https://docs.spring.io/spring-boot/4.1.2/reference/io/email.html)
* [Quartz Scheduler](https://docs.spring.io/spring-boot/4.1.2/reference/io/quartz.html)
* [JobRunr](https://www.jobrunr.io/en/documentation/configuration/spring/)
* [Spring Cache Abstraction](https://docs.spring.io/spring-boot/4.1.2/reference/io/caching.html)
* [Spring Shell](https://docs.spring.io/spring-shell/reference/index.html)
* [Spring gRPC Server](https://docs.spring.io/spring-grpc/reference/server.html)
* [Spring gRPC Client](https://docs.spring.io/spring-grpc/reference/client.html)
* [Spring REST Docs](https://docs.spring.io/spring-restdocs/docs/current/reference/htmlsingle/)
* [Testcontainers](https://java.testcontainers.org/)
* [Embedded LDAP Server](https://docs.spring.io/spring-boot/4.1.2/reference/data/nosql.html#data.nosql.ldap.embedded)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Building a Reactive RESTful Web Service](https://spring.io/guides/gs/reactive-rest-service/)
* [Building a GraphQL service](https://spring.io/guides/gs/graphql-server/)
* [Accessing JPA Data with REST](https://spring.io/guides/gs/accessing-data-rest/)
* [Accessing Neo4j Data with REST](https://spring.io/guides/gs/accessing-neo4j-data-rest/)
* [Accessing MongoDB Data with REST](https://spring.io/guides/gs/accessing-mongodb-data-rest/)
* [Building a Hypermedia-Driven RESTful Web Service](https://spring.io/guides/gs/rest-hateoas/)
* [Producing a SOAP web service](https://spring.io/guides/gs/producing-web-service/)
* [Creating CRUD UI with Vaadin](https://spring.io/guides/gs/crud-with-vaadin/)
* [SpringDoc OpenAPI](https://github.com/springdoc/springdoc-openapi-demos/)
* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)
* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and OAuth2](https://spring.io/guides/tutorials/spring-boot-oauth2/)
* [Authenticating a User with LDAP](https://spring.io/guides/gs/authenticating-ldap/)
* [Okta-Hosted Login Page Example](https://github.com/okta/samples-java-spring/tree/master/okta-hosted-login)
* [Custom Login Page Example](https://github.com/okta/samples-java-spring/tree/master/custom-login)
* [Okta Spring Security Resource Server Example](https://github.com/okta/samples-java-spring/tree/master/resource-server)
* [Accessing Relational Data using JDBC with Spring](https://spring.io/guides/gs/relational-data-access/)
* [Managing Transactions](https://spring.io/guides/gs/managing-transactions/)
* [Using Spring Data JDBC](https://github.com/spring-projects/spring-data-examples/tree/main/jdbc/basics)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Accessing data with R2DBC](https://spring.io/guides/gs/accessing-data-r2dbc/)
* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Messaging with Redis](https://spring.io/guides/gs/messaging-redis/)
* [Messaging with Redis](https://spring.io/guides/gs/messaging-redis/)
* [Accessing Data with MongoDB](https://spring.io/guides/gs/accessing-data-mongodb/)
* [Accessing Data with MongoDB](https://spring.io/guides/gs/accessing-data-mongodb/)
* [Spring Data for Apache Cassandra](https://spring.io/guides/gs/accessing-data-cassandra/)
* [Spring Data Reactive for Apache Cassandra](https://spring.io/guides/gs/accessing-data-cassandra/)
* [Accessing Data with Neo4j](https://spring.io/guides/gs/accessing-data-neo4j/)
* [Integrating Data](https://spring.io/guides/gs/integration/)
* [Messaging with RabbitMQ](https://spring.io/guides/gs/messaging-rabbitmq/)
* [Samples for using Apache Kafka Streams with Spring Cloud stream](https://github.com/spring-cloud/spring-cloud-stream-samples/tree/main/kafka-streams-samples)
* [Java Message Service API via Apache ActiveMQ Classic.](https://spring.io/guides/gs/messaging-jms/)
* [Messaging with JMS](https://spring.io/guides/gs/messaging-jms/)
* [Using WebSocket to build an interactive web application](https://spring.io/guides/gs/messaging-stomp-websocket/)
* [Using Apache Camel with Spring Boot](https://camel.apache.org/camel-spring-boot/latest/spring-boot.html)
* [Creating a Batch Service](https://spring.io/guides/gs/batch-processing/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [JobRunr](https://www.jobrunr.io/en/documentation/getting-started/spring/)
* [Caching Data with Spring](https://spring.io/guides/gs/caching/)

### Additional Links
These additional references should also help you:

* [Configure AOT settings in Build Plugin](https://docs.spring.io/spring-boot/4.1.2/how-to/aot.html)
* [R2DBC Homepage](https://r2dbc.io)
* [R2DBC Homepage](https://r2dbc.io)
* [Various sample apps using Spring gRPC](https://github.com/spring-projects/spring-grpc/tree/main/samples)
* [Various sample apps using Spring gRPC](https://github.com/spring-projects/spring-grpc/tree/main/samples)

## OAuth 2.0 and OIDC with Okta

If you don't have a free Okta developer account, you can create one with [the Okta CLI](https://cli.okta.com):

```bash
$ okta register
```

Then, register your Spring Boot app on Okta using:

```bash
$ okta apps create
```

Select **Web** > **Okta Spring Boot Starter** and accept the default redirect URIs.

## GraphQL code generation with DGS

This project has been configured to use the Netflix DGS Codegen plugin.
This plugin can be used to generate client files for accessing remote GraphQL services.
The default setup assumes that the GraphQL schema file for the remote service is added to the `src/main/resources/graphql-client/` location.

You can learn more about the [plugin configuration options](https://github.com/deweyjose/graphqlcodegen) and
[how to use the generated types](https://netflix.github.io/dgs/generating-code-from-schema/) to adapt the default setup.


### Docker Compose support
This project contains a Docker Compose file named `compose.yaml`.
In this file, the following services have been defined:

* activemq: [`apache/activemq:latest`](https://hub.docker.com/r/apache/activemq)
* artemis: [`apache/artemis:latest`](https://hub.docker.com/r/apache/artemis)
* cassandra: [`cassandra:latest`](https://hub.docker.com/_/cassandra)
* elasticsearch: [`docker.elastic.co/elasticsearch/elasticsearch:9.3.3`](https://www.docker.elastic.co/r/elasticsearch)
* mariadb: [`mariadb:latest`](https://hub.docker.com/_/mariadb)
* mongodb: [`mongo:latest`](https://hub.docker.com/_/mongo)
* mysql: [`mysql:latest`](https://hub.docker.com/_/mysql)
* neo4j: [`neo4j:latest`](https://hub.docker.com/_/neo4j)
* oracle: [`gvenzl/oracle-free:latest`](https://hub.docker.com/r/gvenzl/oracle-free)
* postgres: [`postgres:latest`](https://hub.docker.com/_/postgres)
* pulsar: [`apachepulsar/pulsar:latest`](https://hub.docker.com/r/apachepulsar/pulsar)
* rabbitmq: [`rabbitmq:latest`](https://hub.docker.com/_/rabbitmq)
* redis: [`redis:latest`](https://hub.docker.com/_/redis)
* sqlserver: [`mcr.microsoft.com/mssql/server:latest`](https://mcr.microsoft.com/en-us/product/mssql/server/about/)

Please review the tags of the used images and set them to the same as you're running in production.

## GraalVM Native Support

This project has been configured to let you generate either a lightweight container or a native executable.
It is also possible to run your tests in a native image.

### Lightweight Container with Cloud Native Buildpacks
If you're already familiar with Spring Boot container images support, this is the easiest way to get started.
Docker should be installed and configured on your machine prior to creating the image.

To create the image, run the following goal:

```
$ ./mvnw spring-boot:build-image -Pnative
```

Then, you can run the app like any other container:

```
$ docker run --rm -p 8080:8080 demo:0.0.1-SNAPSHOT
```

### Executable with Native Build Tools
Use this option if you want to explore more options such as running your tests in a native image.
The GraalVM `native-image` compiler should be installed and configured on your machine.

NOTE: GraalVM 25+ is required.

To create the executable, run the following goal:

```
$ ./mvnw native:compile -Pnative
```

Then, you can run the app as follows:
```
$ target/demo
```

You can also run your existing tests suite in a native image.
This is an efficient way to validate the compatibility of your application.

To run your existing tests in a native image, run the following goal:

```
$ ./mvnw test -PnativeTest
```


### Testcontainers support

This project uses [Testcontainers at development time](https://docs.spring.io/spring-boot/4.1.2/reference/features/dev-services.html#features.dev-services.testcontainers).

Testcontainers has been configured to use the following Docker images:

* [`apache/activemq:latest`](https://hub.docker.com/r/apache/activemq)
* [`apache/artemis:latest`](https://hub.docker.com/r/apache/artemis)
* [`cassandra:latest`](https://hub.docker.com/_/cassandra)
* [`docker.elastic.co/elasticsearch/elasticsearch:9.3.3`](https://www.docker.elastic.co/r/elasticsearch)
* [`apache/kafka-native:latest`](https://hub.docker.com/r/apache/kafka-native)
* [`mariadb:latest`](https://hub.docker.com/_/mariadb)
* [`mongo:latest`](https://hub.docker.com/_/mongo)
* [`mysql:latest`](https://hub.docker.com/_/mysql)
* [`neo4j:latest`](https://hub.docker.com/_/neo4j)
* [`gvenzl/oracle-free:latest`](https://hub.docker.com/r/gvenzl/oracle-free)
* [`postgres:latest`](https://hub.docker.com/_/postgres)
* [`apachepulsar/pulsar:latest`](https://hub.docker.com/r/apachepulsar/pulsar)
* [`rabbitmq:latest`](https://hub.docker.com/_/rabbitmq)
* [`redis:latest`](https://hub.docker.com/_/redis)
* [`mcr.microsoft.com/mssql/server:latest`](https://mcr.microsoft.com/en-us/product/mssql/server/about/)

Please review the tags of the used images and set them to the same as you're running in production.

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

